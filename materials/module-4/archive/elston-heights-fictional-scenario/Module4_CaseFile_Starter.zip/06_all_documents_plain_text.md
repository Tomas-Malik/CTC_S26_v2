# Module 4 Source Documents — Plain Text Bundle

Paste this whole file into your AI assistant's context (or upload it as a file)
to ground it in the case, if your tool doesn't support uploading the individual
HTML documents directly. This bundle does **not** include the comparison chart
image (`05_proposal_comparison_chart.png`) — that one only works as an actual
image file, which is the point of Beat Two's image-extraction step.

---

## DOCUMENT 1 — Development Fact Sheet (ORIGINAL, February 2026)

City of Chicago, Department of Planning & Development
Project: The Foundry on Elston
Applicant: Larkspur Development Partners
Site: Former Higgins Auto Parts warehouse, Elston Ave, Elston Heights
Submission date: February 9, 2026
Case number: DPD-2026-0142

Proposed development statistics:
- Total residential units: 80
- Affordable units (share): 8 (10%)
- Building height: 6 stories
- Parking spaces: 48
- Ground-floor retail: Not committed at this stage
- Estimated completion: Early 2028

Note: This fact sheet reflects the applicant's initial submission as filed. It
will be presented at community meetings prior to a zoning committee hearing.
Figures are subject to revision based on community input and committee review.

---

## DOCUMENT 2 — Development Fact Sheet (REVISED, June 2026)

City of Chicago, Department of Planning & Development
Project: The Foundry on Elston — REVISED SUBMISSION
This revised submission (filed June 29, 2026) supersedes the February 9, 2026
fact sheet for the same case.
Applicant: Larkspur Development Partners
Site: Former Higgins Auto Parts warehouse, Elston Ave, Elston Heights
Revised submission date: June 29, 2026
Case number: DPD-2026-0142

Revised development statistics:
- Total residential units: 64
- Affordable units (share): 16 (25%)
- Building height: 4 stories
- Parking spaces: 40
- Ground-floor retail: 6,000 sq ft committed
- Estimated completion: Mid-2028

Note: Changes from the February 9, 2026 submission reflect input from the
February 25 and April 8 community meetings. This fact sheet was presented at
the July 21, 2026 zoning committee hearing.

---

## DOCUMENT 3 — Zoning Committee Public Hearing Minutes

City of Chicago, Case DPD-2026-0142, The Foundry on Elston
Date: July 21, 2026
Location: Elston Heights Community Center, Room 2
Chair: Alderwoman Patricia Voss
Attending members: Voss, Nakamura, Osei, Fitzgerald, Reyes (5 of 5)
Subject: Revised proposal, filed June 29, 2026 (supersedes Feb 9, 2026 submission)

1. Call to order & opening remarks
Alderwoman Voss called the hearing to order at 6:32 PM and summarized the case
history, noting the applicant's revised submission followed two community
meetings (Feb 25, Apr 8, 2026).

Quote — Alderwoman Patricia Voss: "The applicant has come back with a
meaningfully different proposal, and I want tonight's record to reflect what
specifically changed and why."

2. Applicant presentation
Larkspur Development Partners presented the revised statistics: 64 total
units (down from 80), 16 affordable units at 25% (up from 8 at 10%), building
height reduced from 6 to 4 stories, and a new commitment of 6,000 sq ft of
ground-floor retail space. Parking remains at 40 spaces. Estimated completion
mid-2028.

3. Public comment
Quote — Grace Odom (resident): "This isn't the building they showed us in
February, and I think that's a good thing. I'd still like to see the retail
space committed in writing, not just promised."

Quote — Ron Kapoor (resident): "Forty spaces for sixty-four units still
doesn't pencil out on my block. I'm not opposed, I'm cautious."

Four additional residents spoke; general sentiment was mixed-to-positive, with
recurring concern about parking capacity and a recurring request that the
retail commitment be written into the final agreement rather than left as a
stated intention.

4. Committee discussion
Member Nakamura asked whether the retail commitment would be binding; city
staff confirmed it would be written into the final planned-development
agreement if the committee advances the case. Member Fitzgerald noted the
affordability share now exceeds the city's standard minimum set-aside
requirement.

5. Vote
Motion (Reyes, seconded Osei): advance the revised proposal to full council
with a recommendation to approve, contingent on the retail commitment being
written into the final agreement.

Result: 4-1 in favor. Nakamura, Osei, Fitzgerald, Reyes in favor; Voss opposed
(cited continued parking concerns raised in public comment).

Quote — Alderwoman Patricia Voss: "Four in favor, one opposed. The revised
proposal advances to the full council with a recommendation to approve."

6. Next steps
Full city council vote scheduled for August 19, 2026. Minutes prepared by
committee staff; approved for release July 23, 2026.

---

## DOCUMENT 4 — Press Release, Larkspur Development Partners

FOR IMMEDIATE RELEASE
Larkspur Revises Foundry on Elston Proposal, Cites Community Input
CHICAGO — June 29, 2026

Larkspur Development Partners today filed a revised proposal for The Foundry
on Elston, its planned residential and retail redevelopment of the former
Higgins Auto Parts site, following two community meetings earlier this year.

The revised plan reduces the project from 80 to 64 residential units and
lowers the building from six stories to four. The share of units designated
affordable more than doubles, from 10% (8 units) to 25% (16 units). The
revised plan also commits 6,000 square feet of ground-floor space to retail
and neighborhood-serving commercial use, an element not included in the
February submission.

Quote — Marcus Diallo, Larkspur Development Partners: "We heard the concerns
raised in February and April, and this revised plan is a direct response to
that input — fewer units, more of them affordable, and retail space the
neighborhood asked for."

Parking remains at 40 spaces. Larkspur says the revised design keeps the
project financially viable while addressing the height and affordability
concerns raised at the February 25 and April 8 community meetings. The
revised proposal will go before the city's zoning committee on July 21, 2026,
ahead of an anticipated full council vote.

Estimated completion under the revised plan is mid-2028, several months later
than the original early-2028 estimate, reflecting the redesign.

About Larkspur Development Partners: Larkspur is a Chicago-based real estate
development firm focused on mixed-income residential projects in neighborhood
commercial corridors.

Media contact: Marcus Diallo, Larkspur Development Partners

---

## DOCUMENT 5 — Draft Article (NOT YET PUBLISHED — this is what you're fact-checking)

The Elston Heights Bulletin
"Foundry on Elston Clears Committee Ahead of Council Vote"
By Theo Marsh — last edited Aug 14, 2026 — NOT YET PUBLISHED

The Foundry on Elston, the residential and retail development planned for the
site of the old Higgins Auto Parts warehouse, is headed to a full city
council vote on August 19 after clearing the zoning committee last month.

The project, from Larkspur Development Partners, would bring 80 units to the
Elston Heights corridor, with 8 of those set aside as affordable housing. The
six-story building drew a mix of reactions from neighbors when it was first
presented earlier this year, with some residents raising concerns about
height and affordability during community meetings in February and April.

Larkspur has since adjusted the plan in response to that feedback. The
developer says the changes reflect direct input from residents, and the
project now includes a commitment to ground-floor retail space — an addition
from the original pitch.

At the July 21 zoning committee hearing, Alderwoman Patricia Voss noted the
applicant had "come back with a meaningfully different proposal." The
committee voted 4-1 to advance the project to the full council with a
recommendation to approve. Parking is set at 40 spaces.

Some residents remain cautious. "Forty spaces for sixty-four units still
doesn't pencil out on my block," resident Ron Kapoor said at the hearing.
Others were more optimistic about the direction of the changes.

If approved by the full council on August 19, construction could begin as
early as this fall, with completion estimated in 2028.

Editor's note (Dana): Theo — before this runs, I need every figure in here
checked against the actual case file, not against whatever's floating around
from earlier in the year. Get me a fact-checked version before Monday. — D.

---

*(Not included in this text bundle: `05_proposal_comparison_chart.png` — the
image file with the units comparison chart. Feed that in separately.)*
