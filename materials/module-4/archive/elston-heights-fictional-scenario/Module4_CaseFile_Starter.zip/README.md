# Module 4 Case File — Starter Kit

The Elston Heights Bulletin case file for "The Foundry on Elston." Everything
you need for all three beats of Module 4.

## What's in here

- `00_original_fact_sheet.html` — February 2026 proposal (now superseded)
- `01_revised_fact_sheet.html` — June 2026 revised proposal (the current record)
- `02_hearing_minutes.html` — July 21, 2026 zoning committee hearing minutes
- `03_press_release.html` — Larkspur Development Partners' press release
- `04_draft_article.html` — Theo's draft article — **this is what you're fact-checking**
- `05_proposal_comparison_chart.png` — comparison chart image (units, original vs. revised)
- `06_all_documents_plain_text.md` — every text document above, concatenated, for AI tools that can't accept file uploads (does not include the chart image — that one only works as an actual image)

## How to use it

1. **Beat One:** ask your AI assistant about the Foundry on Elston project *before* giving it any of these files. Then attach all of these documents (or paste in `06_all_documents_plain_text.md`) and ask again.
2. **Beat Two:** pull exact facts from the documents, then check `04_draft_article.html` against the rest of the case file.
3. **Beat Three:** ask a synthesis question that isn't answered verbatim anywhere, and figure out how to verify it anyway.

Full instructions are in the Module 4 Lab Guide, not here.
