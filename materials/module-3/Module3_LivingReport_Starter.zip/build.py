#!/usr/bin/env python3
"""
Module 3 — Data On Demand: rebuild script.

Reads every Pinnacle_Peak_Revenue_*.xlsx file in ./data, turns it into one
combined time series, and writes report/data.json — the file the living
report (report/index.html) fetches when you open it in a browser.

Usage:
    python3 build.py

Then serve the report/ folder locally, e.g.:
    cd report && python3 -m http.server 8000
and open http://localhost:8000/ in a browser.

Re-run this script any time the data/ folder changes — that's "hit rebuild."
"""
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

import openpyxl

HERE = Path(__file__).parent
DATA_DIR = HERE / "data"
OUT_PATH = HERE / "report" / "data.json"

MONTHS = ["January", "February", "March", "April", "May", "June",
          "July", "August", "September", "October", "November", "December"]

FILENAME_RE = re.compile(r"Pinnacle_Peak_Revenue_(\d{4})(?:_H([12]))?\.xlsx$")


def parse_number(value):
    """Convert a spreadsheet cell to a float. Handles the plain numeric cells
    every file has used so far (2023-2026 H1)."""
    return float(value)


def load_file(path):
    """Parse one Pinnacle_Peak_Revenue_*.xlsx file into a list of monthly
    records. Returns (records, warnings)."""
    m = FILENAME_RE.search(path.name)
    if not m:
        return [], [f"{path.name}: filename doesn't match the expected pattern, skipped"]
    year = int(m.group(1))

    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb.worksheets[0]  # the monthly-revenue sheet is always first

    # Find the header row (the row whose first cell is exactly "Month")
    header_row = None
    for row in ws.iter_rows(min_row=1, max_row=6):
        if row[0].value == "Month":
            header_row = row[0].row
            break
    if header_row is None:
        return [], [f"{path.name}: couldn't find a header row starting with 'Month', skipped"]

    records = []
    warnings = []
    for row in ws.iter_rows(min_row=header_row + 1, max_row=ws.max_row):
        month = row[0].value
        if month not in MONTHS:
            break  # end of the monthly data block (blank row / totals below)
        quarter = row[1].value
        try:
            hvac = parse_number(row[2].value)
            plumbing = parse_number(row[3].value)
            cleaning = parse_number(row[4].value)
            total = parse_number(row[5].value)
        except (TypeError, ValueError) as exc:
            warnings.append(
                f"{path.name}: skipped {month} {year} — couldn't parse a revenue "
                f"value ({exc})"
            )
            continue
        records.append({
            "year": year,
            "month": month,
            "monthIndex": MONTHS.index(month),
            "quarter": quarter,
            "hvac": hvac,
            "plumbing": plumbing,
            "cleaning": cleaning,
            "total": total,
            "source": path.name,
        })
    return records, warnings


def main():
    if not DATA_DIR.exists():
        print(f"ERROR: {DATA_DIR} doesn't exist.", file=sys.stderr)
        sys.exit(1)

    files = sorted(DATA_DIR.glob("Pinnacle_Peak_Revenue_*.xlsx"))
    if not files:
        print(f"ERROR: no Pinnacle_Peak_Revenue_*.xlsx files found in {DATA_DIR}", file=sys.stderr)
        sys.exit(1)

    all_records = []
    all_warnings = []
    loaded_files = []
    print(f"Rebuilding from {len(files)} file(s) in {DATA_DIR}:")
    for path in files:
        records, warnings = load_file(path)
        print(f"  {path.name}: {len(records)} month(s) parsed"
              + (f", {len(warnings)} warning(s)" if warnings else ""))
        for w in warnings:
            print(f"    WARNING: {w}")
        all_records.extend(records)
        all_warnings.extend(warnings)
        loaded_files.append(path.name)

    all_records.sort(key=lambda r: (r["year"], r["monthIndex"]))

    payload = {
        "generatedAt": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "sourceFiles": loaded_files,
        "warnings": all_warnings,
        "records": all_records,
    }
    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUT_PATH.write_text(json.dumps(payload, indent=2))
    print(f"\nWrote {len(all_records)} months of data -> {OUT_PATH}")
    if all_warnings:
        print(f"{len(all_warnings)} warning(s) — see above, or the build log in the report footer.")


if __name__ == "__main__":
    main()
